# Horizontal scroll section with GSAP ScrollTrigger & Locomotive Scroll

A Pen created on CodePen.io. Original URL: [https://codepen.io/cameronknight/pen/qBNvrRQ](https://codepen.io/cameronknight/pen/qBNvrRQ).

